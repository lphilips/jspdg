function f()
{
  h()
}

function g()
{
  h()
}

function h()
{
  "here";
}

f()
g()
f()