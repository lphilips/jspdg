function f()
{
  g()
}

function g()
{
  h()
}

function h()
{
  "here";
}

f()