var z = true; 

function f()
{
  z = false;
}

f()
