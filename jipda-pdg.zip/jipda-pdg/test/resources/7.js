var z = true; 

function f()
{
  var z = true;
  z = false;
}

f()
