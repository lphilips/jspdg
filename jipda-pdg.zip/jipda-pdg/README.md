JIPDA: static analysis for JavaScript
=====================================

JIPDA is a static analyzer for JavaScript, written in JavaScript.


JIPDA projects/clients
======================

###STIP: Slicing Tierless JavaScript Programs
https://github.com/lphilips/jspdg

###Purity analysis in JavaScript
https://github.com/jensnicolay/jipda/protopurity
